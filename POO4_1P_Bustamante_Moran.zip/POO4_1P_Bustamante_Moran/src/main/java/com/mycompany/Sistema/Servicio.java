package com.mycompany.proyecto1p;

public abstract class Servicio{

    private int IdServicio;
    private String tipoDeServicio;
    private String conductor;
    private String desde;
    private String hasta;
    private String fecha;
    private String hora;

    public Servicios(String fecha, String nombreConductor, double valorAPagar) {
        // <editor-fold defaultstate="collapsed" desc="Compiled Code">
        /* 0: aload_0
         * 1: invokespecial #1                  // Method com/mycompany/proyecto1p/Cliente."<init>":()V
         * 4: aload_0
         * 5: aload_1
         * 6: putfield      #7                  // Field fecha:Ljava/lang/String;
         * 9: aload_0
         * 10: aload_2
         * 11: putfield      #13                 // Field nombreConductor:Ljava/lang/String;
         * 14: return
         *  */
        // </editor-fold>
    }

    public Servicios() {
        // <editor-fold defaultstate="collapsed" desc="Compiled Code">
        /* 0: aload_0
         * 1: invokespecial #1                  // Method com/mycompany/proyecto1p/Cliente."<init>":()V
         * 4: return
         *  */
        // </editor-fold>
    }

    public abstract void calcularValorAPgagar(String fecha);
}

    
