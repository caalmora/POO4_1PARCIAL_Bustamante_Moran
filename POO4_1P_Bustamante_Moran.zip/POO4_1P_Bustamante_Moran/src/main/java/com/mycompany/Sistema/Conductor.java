
package com.mycompany.proyecto1p;

import java.util.ArrayList;
import java.util.Scanner;

public class Conductor extends Usuario {
    private int edad;
    private String numeroLicencia;
    private TipoEstadoConducto estado;
    private Vehiculo vehiculo;

    public Conductor(int edad, String numeroLicencia, TipoEstadoConducto estado, Vehiculo vehiculo, String cedula, String nombre, String apellido, String user, String contraseña, String numeroCelular, String tipoDeUsuario) {
        super(cedula, nombre, apellido, user, contraseña, numeroCelular, tipoDeUsuario);
        this.edad = edad;
        this.numeroLicencia = numeroLicencia;
        this.estado = estado;
        this.vehiculo = vehiculo;
    }

    public int getEdad() {
        return edad;
    }

    public String getNumeroLicencia() {
        return numeroLicencia;
    }

    public TipoEstadoConducto getEstado() {
        return estado;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setNumeroLicencia(String numeroLicencia) {
        this.numeroLicencia = numeroLicencia;
    }

    public void setEstado(TipoEstadoConducto estado) {
        this.estado = estado;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }
    
    public int tiposDeServicio() {
        System.out.println("1. Consultar Servicio Asignado");
        System.out.println("2. Datos de su vehículo");
        Scanner sc = new Scanner(System.in);
        System.out.print("Elija una opcion: ");
        int Opcion = sc.nextInt();
        return Opcion;

    }
    
    
    
}

