package com.mycompany.proyecto1p;

import java.util.ArrayList;
import java.util.Scanner;

public class Cliente extends Usuario {
    private String numeroDeTarjeta;
    private int edad;

    public String getNumeroDeTarjeta() {
        return numeroDeTarjeta;
    }

    public int getEdad() {
        return edad;
    }

    public void setNumeroDeTarjeta(String numeroDeTarjeta) {
        this.numeroDeTarjeta = numeroDeTarjeta;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    
    public Cliente(String numeroDeTarjeta, int edad) {
        this.numeroDeTarjeta = numeroDeTarjeta;
        this.edad = edad;
    }


    public boolean verificarCliente(Usuario user) {
        String clientesA = "clientes.txt";
        ArrayList<String> lineas = ManejoArchivos.LeeFichero(clientesA);
        int acceso = 0;

        for (String linea : lineas) {
            String[] sepa = linea.split(",");
            String numeroCedula = sepa[0];
            int edadCliente = Integer.parseInt(sepa[1]);
            String tarjetaDeCredito = sepa[2];
            if (user.cedula.equals(numeroCedula)) {
                acceso++;
            }
        }
        if (acceso == 1) {
            return true;
        } else {
            System.out.println("Sus datos no constan en el sistema, por favor ingresarlos");
            Scanner sc = new Scanner(System.in);
            System.out.println("Ingrese su numero de tarjeta");
            numeroDeTarjeta = sc.nextLine();
            System.out.println("Ingrese su edad");
            edad = sc.nextInt();

            Cliente clp = new Cliente(numeroDeTarjeta, edad);
            String clientesArchivo = "clientes.txt";
            String lineaAEscribir = "\n" + user.cedula + "," + edad + "," + numeroDeTarjeta;
            ManejoArchivos.EscribirArchivo(clientesArchivo, lineaAEscribir);
            return true;

        }

    }

    public int tiposDeServicio() {
        System.out.println("1. Solicitar servicio de taxi");
        // System.out.println("2. Solicitar comida a domicilio");
        System.out.println("3. Solicitar entrega encomienda");
        System.out.println("4. consultar servicios");
        Scanner sc = new Scanner(System.in);
        System.out.print("Elija una opcion: ");
        int Opcion = sc.nextInt();
        return Opcion;

    }

    public String solicitarServicio(int opcion) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Fecha de viaje: ");
        String fecha1 = sc.nextLine();

        switch (opcion) {
            case 1:
                Taxi taxi = new Taxi();
                taxi.calcularValorAPgagar(fecha1);
                break;
            case 3:
                Encomienda encomienda = new Encomienda();
                encomienda.calcularValorAPgagar(fecha1);
                break;
            case 4:
                ConsultarServicios consulta = new ConsultarServicios();
                consulta.consultarServicios();
                break;
            default:
                break;
        }

        return fecha1;

    }

    public void consultarServicios(){
        String nombreArchivo = "Servicios.txt";
        ArrayList<String> lineas = ManejoArchivos.LeeFichero(nombreArchivo);

        for (String linea : lineas) {
            String[] sep = linea.split(",");
            String numeroE = sep[0];
            String tipo = sep[1];
            String cedulaC = sep[2];
            String nombreCon = sep[3];
            String desde = sep[4];
            String hasta = sep[5];
            String hora = sep[6];

            System.out.println("----------" + "Detelles del servicio" + "----------");
            System.out.println("Numero de servicio: " + numeroE);
            System.out.println("Tipo de servicio: " + tipo);
            System.out.println("Cedula del cliente: " + cedulaC);
            System.out.println("Nombre del conductor " + nombreCon);
            System.out.println("Desde: " + desde);
            System.out.println("Hasta: " + hasta);
            System.out.println("Hora: " + hora);

            System.out.println("-----------------------------------------------");
        }

    }

}
