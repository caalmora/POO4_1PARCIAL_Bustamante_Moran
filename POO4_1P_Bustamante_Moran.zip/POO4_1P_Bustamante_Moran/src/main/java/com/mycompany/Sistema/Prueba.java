
package com.mycompany.proyecto1p;


public class Prueba {
    public static void main(String[] args) {
        String clientesArchivo = "clientes.txt";
        String lineaAEscribir = "pollo";

        ManejoArchivos.EscribirArchivo(clientesArchivo, lineaAEscribir);
    }
}

    
